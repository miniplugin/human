
Install prerequisites

```bash
sudo apt-get update
sudo apt-get install build-essential
sudo apt-get install cmake
sudo apt-get install qtcreator
sudo apt-get install qt5-default
```

프로젝트파일을 만들어두고, open만 해서 실행해볼 수 있도록...
