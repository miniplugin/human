#!/bin/bash
sudo ./test
