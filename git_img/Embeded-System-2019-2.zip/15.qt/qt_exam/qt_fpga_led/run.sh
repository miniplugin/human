sudo ./qt_fpga_led
