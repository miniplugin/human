package core;

/**
 * Created by kimilguk on 2015-12-13.
 */
public interface AsyncResponse {
    void processFinish(String output);
}
